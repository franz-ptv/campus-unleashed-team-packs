#!/bin/sh
# copies the site to the web server
rsync -av ./ deploy@web.hunebed-hosting.example.invalid:/var/www/
